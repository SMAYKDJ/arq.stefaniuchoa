<?php
session_start();
require_once 'db_connect.php';

// Processamento do formulário de contato
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $telefone = htmlspecialchars($_POST['telefone']);
    $assunto = htmlspecialchars($_POST['assunto']);
    $mensagem = htmlspecialchars($_POST['mensagem']);

    // Validação básica
    if (empty($nome) || empty($email) || empty($assunto) || empty($mensagem)) {
        $_SESSION['error'] = "Por favor, preencha todos os campos obrigatórios!";
        header('Location: index.php#contato');
        exit;
    }

    // Insere o contato no banco
    $stmt = $conn->prepare("INSERT INTO contatos (nome, email, telefone, assunto, mensagem) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("sssss", $nome, $email, $telefone, $assunto, $mensagem);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Mensagem enviada com sucesso! Entraremos em contato em breve.";
        header('Location: index.php#contato');
        exit;
    } else {
        $_SESSION['error'] = "Erro ao enviar a mensagem. Tente novamente.";
        header('Location: index.php#contato');
        exit;
    }

    $stmt->close();
}

$conn->close();
?>
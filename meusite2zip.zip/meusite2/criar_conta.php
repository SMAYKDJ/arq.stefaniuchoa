<?php
session_start();
require_once 'db_connect.php';

// Verifica se há mensagem de erro ou sucesso
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);

// Processamento do formulário de criação de conta
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['criar_conta'])) {
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);
    $senha = $_POST['senha'];

    // Validação básica
    if (strlen($senha) < 6) {
        $_SESSION['error'] = "A senha deve ter pelo menos 6 caracteres!";
        header('Location: criar_conta.php');
        exit;
    }

    // Verifica se o email já existe
    $stmt = $conn->prepare("SELECT email FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $_SESSION['error'] = "Este email já está registrado!";
        header('Location: criar_conta.php');
        exit;
    }

    // Criptografa a senha
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

    // Insere o novo usuário
    $stmt = $conn->prepare("INSERT INTO users (nome, email, senha) VALUES (?, ?, ?)");
    $stmt->bind_param("sss", $nome, $email, $senha_hash);
    
    if ($stmt->execute()) {
        $_SESSION['success'] = "Conta criada com sucesso! Faça login.";
        header('Location: index.php');
        exit;
    } else {
        $_SESSION['error'] = "Erro ao criar a conta. Tente novamente.";
        header('Location: criar_conta.php');
        exit;
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criar Conta - Stéfani Uchôa</title>
    <meta name="description" content="Crie sua conta - Stéfani Uchôa Arquitetura e Urbanismo">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* Variáveis CSS */
        :root {
            --primary: #2A5C7D;
            --secondary: #C5A47E;
            --accent: #F8F9FA;
            --dark: #1A1A1A;
            --light: #FFFFFF;
            --text: #333333;
            --text-light: #777777;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --border-radius: 8px;
            --max-width: 1200px;
        }

        /* Reset e Base */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            line-height: 1.6;
            color: #2A5C7D;
            background-color: var(--light);
            overflow-x: hidden;
        }

        .container {
            width: 90%;
            max-width: var(--max-width);
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Formulário de Criação de Conta */
        .create-account-section {
            padding: 100px 0;
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .create-account-container {
            background-color: var(--light);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            max-width: 500px;
            width: 100%;
            text-align: center;
        }

        .create-account-container h2 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 30px;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
        }

        .btn-primary {
            display: inline-block;
            padding: 12px 30px;
            background-color: var(--primary);
            color: var(--light);
            border-radius: var(--border-radius);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: var(--transition);
            border: none;
            cursor: pointer;
            width: 100%;
        }

        .btn-primary:hover {
            background-color: #1e4560;
            transform: translateY(-3px);
            box-shadow: var(--shadow);
        }

        /* Error/Success Messages */
        .error-message, .success-message {
            padding: 10px;
            margin: 10px 0;
            border-radius: var(--border-radius);
            text-align: center;
        }

        .error-message {
            background-color: #ffe6e6;
            color: #cc0000;
        }

        .success-message {
            background-color: #e6ffe6;
            color: #006600;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .create-account-container {
                padding: 20px;
            }

            .create-account-section {
                padding: 60px 0;
            }
        }
    </style>
</head>
<body>
    <section class="create-account-section">
        <div class="container">
            <div class="create-account-container">
                <h2>Criar Conta</h2>
                <?php if ($error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success-message"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <form action="criar_conta.php" method="post">
                    <div class="form-group">
                        <input type="text" class="form-control" placeholder="Nome" name="nome" required>
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control" placeholder="Email" name="email" required>
                    </div>
                    <div class="form-group">
                        <input type="password" class="form-control" placeholder="Senha" name="senha" required>
                    </div>
                    <button type="submit" class="btn-primary" name="criar_conta">Criar Conta</button>
                </form>
            </div>
        </div>
    </section>
</body>
</html>
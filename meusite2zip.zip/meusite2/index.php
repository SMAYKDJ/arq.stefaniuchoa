<script type="text/javascript">
        var gk_isXlsx = false;
        var gk_xlsxFileLookup = {};
        var gk_fileData = {};
        function filledCell(cell) {
          return cell !== '' && cell != null;
        }
        function loadFileData(filename) {
        if (gk_isXlsx && gk_xlsxFileLookup[filename]) {
            try {
                var workbook = XLSX.read(gk_fileData[filename], { type: 'base64' });
                var firstSheetName = workbook.SheetNames[0];
                var worksheet = workbook.Sheets[firstSheetName];

                // Convert sheet to JSON to filter blank rows
                var jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1, blankrows: false, defval: '' });
                // Filter out blank rows (rows where all cells are empty, null, or undefined)
                var filteredData = jsonData.filter(row => row.some(filledCell));

                // Heuristic to find the header row by ignoring rows with fewer filled cells than the next row
                var headerRowIndex = filteredData.findIndex((row, index) =>
                  row.filter(filledCell).length >= filteredData[index + 1]?.filter(filledCell).length
                );
                // Fallback
                if (headerRowIndex === -1 || headerRowIndex > 25) {
                  headerRowIndex = 0;
                }

                // Convert filtered JSON back to CSV
                var csv = XLSX.utils.aoa_to_sheet(filteredData.slice(headerRowIndex)); // Create a new sheet from filtered array of arrays
                csv = XLSX.utils.sheet_to_csv(csv, { header: 1 });
                return csv;
            } catch (e) {
                console.error(e);
                return "";
            }
        }
        return gk_fileData[filename] || "";
        }
        </script><?php
session_start();
require_once 'db_connect.php';

// Verifica se há mensagem de erro ou sucesso
$error = isset($_SESSION['error']) ? $_SESSION['error'] : '';
$success = isset($_SESSION['success']) ? $_SESSION['success'] : '';
unset($_SESSION['error'], $_SESSION['success']);

// Configuração básica de login admin
$usuarios_admin = [
    'admin' => '123456',
    'stefani' => 'admin123',
    'smayk' => 'SENHA_DO_SMAYK' // Defina a senha desejada
];

// Processamento do formulário de login
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['login'])) {
    $email = htmlspecialchars($_POST['email']);
    $senha = $_POST['senha'];

    // Verifica login admin
    if ($email === $usuario_admin && $senha === $senha_admin) {
        $_SESSION['logado'] = true;
        $_SESSION['is_admin'] = true;
        $_SESSION['nome'] = 'Administrador';
        $_SESSION['success'] = "Login admin realizado com sucesso!";
        header('Location: admin.php');
        exit;
    } else {
        // Verifica login de usuário comum
        $stmt = $conn->prepare("SELECT id, nome, senha FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            if (password_verify($senha, $user['senha'])) {
                $_SESSION['logado'] = true;
                $_SESSION['is_admin'] = false;
                $_SESSION['nome'] = $user['nome'];
                $_SESSION['success'] = "Login realizado com sucesso!";
                header('Location: index.php');
                exit;
            } else {
                $_SESSION['error'] = "Senha incorreta!";
                header('Location: index.php');
                exit;
            }
        } else {
            $_SESSION['error'] = "Usuário não encontrado!";
            header('Location: index.php');
            exit;
        }
        $stmt->close();
    }
}

// Processamento do logout
if (isset($_POST['logout'])) {
    session_destroy();
    $_SESSION['success'] = "Logout realizado com sucesso!";
    header('Location: index.php');
    exit;
}

// Dados simulados de projetos para a Área do Cliente
$projetos = [
    ['nome' => 'Projeto Residencial', 'status' => 'Em Andamento', 'ultima_atualizacao' => '2025-06-15'],
    ['nome' => 'Design de Interiores', 'status' => 'Concluído', 'ultima_atualizacao' => '2025-05-30'],
    ['nome' => 'Regularização de Imóvel', 'status' => 'Em Andamento', 'ultima_atualizacao' => '2025-06-10']
];

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stéfani Uchôa - Arquitetura e Urbanismo | Macapá-AP</title>
    <meta name="description" content="Arquiteta e Urbanista em Macapá-AP oferecendo projetos residenciais, regularização de imóveis e design de interiores">
    
    <!-- Favicon -->
    <link rel="icon" href="favicon.ico" type="image/x-icon">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;500;700&display=swap" rel="stylesheet">
    
    <!-- LightGallery CSS -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/css/lightgallery.min.css">
    
    <!-- Swiper CSS -->
    <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">
    
    <style>
        /* Variáveis CSS */
        :root {
            --primary: #2A5C7D;
            --secondary: #C5A47E;
            --accent: #F8F9FA;
            --dark: #1A1A1A;
            --light: #FFFFFF;
            --text: #333333;
            --text-light: #777777;
            --shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            --transition: all 0.3s ease;
            --border-radius: 8px;
            --max-width: 1200px;
        }

        /* Font Face */
        @font-face {
            font-family: 'TT Knickerbockers Grotesk';
            src: url('fonts/TTKnickerbockersGrotesk.otf') format('opentype');
            font-weight: normal;
            font-style: normal;
        }

        /* Reset e Base */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            line-height: 1.6;
            color: #2A5C7D;
            background-color: var(--light);
            overflow-x: hidden;
        }

        h1, h2, h3, h4 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            color: var(--primary);
        }

        a {
            text-decoration: none;
            color: inherit;
            transition: var(--transition);
        }

        ul {
            list-style: none;
        }

        img {
            max-width: 100%;
            height: auto;
            display: block;
        }

        .container {
            width: 90%;
            max-width: var(--max-width);
            margin: 0 auto;
            padding: 0 15px;
        }

        .btn {
            display: inline-block;
            padding: 12px 30px;
            background-color: var(--secondary);
            color: var(--dark);
            border-radius: var(--border-radius);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: var(--transition);
            border: none;
            cursor: pointer;
        }

        .btn:hover {
            background-color: #b5956e;
            transform: translateY(-3px);
            box-shadow: var(--shadow);
        }

        .btn-outline {
            background-color: transparent;
            border: 2px solid var(--secondary);
            color: var(--secondary);
        }

        .btn-outline:hover {
            background-color: var(--secondary);
            color: var(--dark);
        }

        .section {
            padding: 80px 0;
        }

        .section-title {
            text-align: center;
            margin-bottom: 50px;
            position: relative;
        }

        .section-title::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 80px;
            height: 3px;
            background-color: var(--secondary);
        }

        /* Header */
        .header {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            z-index: 1000;
            background-color: rgba(255, 255, 255, 0.95);
            box-shadow: var(--shadow);
            transition: var(--transition);
        }

        .header.scrolled {
            background-color: rgba(255, 255, 255, 0.98);
            padding: 10px 0;
        }

        .header-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
        }

        .logo {
            display: flex;
            align-items: center;
            text-decoration: none;
        }

        .logo-wrapper {
            display: flex;
            align-items: center;
            gap: 15px;
        }

        .logo-text {
            display: flex;
            flex-direction: column;
            line-height: 1.2;
        }

        .logo-text p {
            margin: 0;
        }

        .logo-text p:first-child {
            font-weight: 700;
            font-size: 1.1rem;
        }

        .logo-text p:last-child {
            font-size: 0.8rem;
            color: var(--secondary);
        }

        .nav {
            display: flex;
            align-items: center;
        }

        .nav-list {
            display: flex;
            align-items: center;
        }

        .nav-item {
            margin-left: 30px;
            position: relative;
        }

        .nav-link {
            font-weight: 600;
            padding: 5px 0;
        }

        .nav-link::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--secondary);
            transition: var(--transition);
        }

        .nav-link:hover::after {
            width: 100%;
        }

        .mobile-menu-btn {
            display: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary);
            background: none;
            border: none;
        }

        /* Login Form no Menu */
        .login-form {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .login-form .form-control {
            padding: 8px 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 0.9rem;
            width: 120px;
        }

        .login-form .btn-primary {
            padding: 8px 15px;
            background-color: var(--primary);
            color: var(--light);
            font-size: 0.9rem;
            border-radius: var(--border-radius);
            cursor: pointer;
        }

        .login-form .btn-primary:hover {
            background-color: #1e4560;
            transform: translateY(-2px);
        }

        /* Ícone de Sanduíche e Menu Suspenso */
        .menu-toggle {
            font-size: 1.5rem;
            cursor: pointer;
            color: var(--primary);
            background: none;
            border: none;
            padding: 5px;
            transition: var(--transition);
        }

        .menu-toggle:hover {
            color: var(--secondary);
        }

        .client-area {
            position: absolute;
            top: 100%;
            right: 0;
            min-width: 350px;
            width: auto;
            max-width: 90vw;
            background-color: var(--accent);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            padding: 25px;
            display: none;
            z-index: 1000;
            box-sizing: border-box;
        }

        .client-area.active {
            display: block;
            animation: slideDown 0.4s ease-in-out;
        }

        .client-area h3 {
            font-size: 1.2rem;
            margin-bottom: 20px;
            color: var(--primary);
            text-align: center;
        }

        .client-table-container {
            max-height: 400px;
            overflow-y: auto;
            margin-bottom: 20px;
            border: 1px solid var(--secondary);
            border-radius: var(--border-radius);
        }

        .client-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.85rem;
            white-space: nowrap;
        }

        .client-table th, .client-table td {
            padding: 12px 15px;
            border: 1px solid var(--secondary);
            text-align: left;
        }

        .client-table th {
            background-color: var(--primary);
            color: var(--light);
            font-weight: 600;
            position: sticky;
            top: 0;
        }

        .client-table tr:nth-child(even) {
            background-color: rgba(197, 164, 126, 0.1);
        }

        .client-table tr:hover {
            background-color: rgba(197, 164, 126, 0.2);
        }

        .action-link {
            color: var(--primary);
            font-weight: 500;
            transition: var(--transition);
        }

        .action-link:hover {
            color: var(--secondary);
            text-decoration: underline;
        }

        /* Hero Section */
        .hero {
            height: 100vh;
            min-height: 700px;
            background: linear-gradient(rgba(42, 92, 125, 0.8), rgba(42, 92, 125, 0.8)), 
                        url('https://t4.ftcdn.net/jpg/02/58/35/79/360_F_258357963_WtmCoxgNrrQsvrufPzNrgSFIFEE8ESRa.jpg') no-repeat center center/cover;
            display: flex;
            align-items: center;
            color: var(--light);
            text-align: center;
            position: relative;
            z-index: 1;
        }

        .hero-content {
            position: relative;
            z-index: 2;
        }

        .hero-title {
            font-size: 3rem;
            margin-bottom: 20px;
            animation: fadeInDown 1s ease;
            color: #FFFFFF;
        }

        .hero-subtitle {
            font-size: 1.3rem;
            margin-bottom: 30px;
        }

        .cau-badge {
            display: inline-block;
            background-color: var(--light);
            color: var(--primary);
            padding: 8px 20px;
            border-radius: 20px;
            font-weight: 600;
            font-size: 0.9rem;
            margin-top: 20px;
            animation: fadeIn 1.5s ease;
        }

        /* Services Section */
        .services-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .service-card {
            text-align: center;
            padding: 40px 30px;
            background-color: var(--light);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            transition: var(--transition);
            border-left: 4px solid var(--secondary);
        }

        .service-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.1);
        }

        .service-icon {
            font-size: 2.5rem;
            color: var(--secondary);
            margin-bottom: 20px;
        }

        .service-title {
            font-size: 1.3rem;
            margin-bottom: 15px;
            color: var(--primary);
        }

        .service-text {
            color: var(--text-light);
        }

        /* Projects Section */
        .projects {
            background-color: var(--accent);
        }

        .swiper-container {
            width: 100%;
            height: 400px;
            padding: 20px 0;
            position: relative;
        }

        .swiper-slide {
            width: calc(100% / 3 - 20px);
            height: 100%;
            overflow: hidden;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            transition: transform 0.3s ease;
        }

        .swiper-slide:hover {
            transform: translateY(-5px);
        }

        .swiper-slide img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s ease;
        }

        .swiper-slide:hover img {
            transform: scale(1.05);
        }

        .swiper-wrapper {
            display: flex;
            align-items: center;
            transition-timing-function: linear;
        }

        .swiper-button-next,
        .swiper-button-prev {
            color: var(--secondary);
            background-color: rgba(255, 255, 255, 0.9);
            width: 50px;
            height: 50px;
            border-radius: 50%;
            box-shadow: var(--shadow);
            transition: var(--transition);
            opacity: 0.8;
        }

        .swiper-button-next::after,
        .swiper-button-prev::after {
            font-size: 1.5rem;
            font-weight: bold;
        }

        .swiper-button-next:hover,
        .swiper-button-prev:hover {
            background-color: var(--secondary);
            color: var(--dark);
            transform: scale(1.1);
            opacity: 1;
        }

        .swiper-pagination-bullet {
            background: var(--secondary);
        }

        /* Process Timeline Section */
        .process-section {
            background-color: var(--light);
        }

        .process-timeline {
            position: relative;
            max-width: 800px;
            margin: 0 auto;
            padding-left: 50px;
        }

        .process-timeline::before {
            content: '';
            position: absolute;
            top: 0;
            left: 35px;
            height: 100%;
            width: 2px;
            background-color: var(--secondary);
        }

        .process-item {
            position: relative;
            margin-bottom: 40px;
            padding-bottom: 20px;
        }

        .process-item:last-child {
            margin-bottom: 0;
            padding-bottom: 0;
        }

        .process-icon {
            position: absolute;
            left: -50px;
            top: 0;
            width: 40px;
            height: 40px;
            background-color: var(--secondary);
            color: var(--dark);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            box-shadow: var(--shadow);
        }

        .process-content {
            background-color: var(--accent);
            padding: 25px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            position: relative;
        }

        .process-content::before {
            content: '';
            position: absolute;
            left: -15px;
            top: 20px;
            width: 0;
            height: 0;
            border-top: 15px solid transparent;
            border-bottom: 15px solid transparent;
            border-right: 15px solid var(--accent);
        }

        .process-content h3 {
            margin-bottom: 10px;
            color: var(--primary);
        }

        /* Contact Section */
        .contact-container {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 50px;
        }

        .contact-info h3 {
            margin-bottom: 20px;
        }

        .contact-item {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }

        .contact-icon {
            width: 50px;
            height: 50px;
            background-color: var(--secondary);
            color: var(--dark);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            margin-right: 15px;
            flex-shrink: 0;
        }

        .contact-text h4 {
            font-size: 1.1rem;
            margin-bottom: 5px;
        }

        .contact-text p, .contact-text a {
            color: var(--text-light);
        }

        .contact-form .form-group {
            margin-bottom: 20px;
        }

        .contact-form .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
        }

        .contact-form textarea {
            min-height: 150px;
            resize: vertical;
        }

        .social-links {
            display: flex;
            gap: 15px;
            margin-top: 30px;
        }

        .social-link {
            width: 40px;
            height: 40px;
            background-color: rgba(42, 92, 125, 0.1);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: var(--transition);
        }

        .social-link:hover {
            background-color: var(--secondary);
            transform: translateY(-5px);
            color: var(--dark);
        }

        /* Footer */
        .footer {
            background-color: var(--dark);
            color: var(--light);
            padding: 60px 0 0;
        }

        .footer-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }

        .footer-col h3 {
            color: var(--light);
            margin-bottom: 25px;
            position: relative;
            padding-bottom: 10px;
        }

        .footer-col h3::after {
            content: '';
            position: absolute;
            left: 0;
            bottom: 0;
            width: 50px;
            height: 2px;
            background-color: var(--secondary);
        }

        .footer-about p {
            margin-bottom: 20px;
            color: #bbb;
        }

        .footer-links li {
            margin-bottom: 10px;
        }

        .footer-links a {
            color: #bbb;
            transition: var(--transition);
        }

        .footer-links a:hover {
            color: var(--secondary);
            padding-left: 5px;
        }

        .footer-contact p {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            color: #bbb;
        }

        .footer-contact i {
            margin-right: 10px;
            color: var(--secondary);
        }

        .footer-bottom {
            text-align: center;
            padding: 20px 0;
            border-top: 1px solid rgba(255, 255, 255, 0.1);
            color: #bbb;
            font-size: 0.9rem;
        }

        /* Back to Top Button */
        .back-to-top {
            position: fixed;
            bottom: 30px;
            right: 30px;
            width: 50px;
            height: 50px;
            background-color: var(--secondary);
            color: var(--dark);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.2rem;
            cursor: pointer;
            opacity: 0;
            visibility: hidden;
            transition: var(--transition);
            z-index: 999;
            border: none;
        }

        .back-to-top.active {
            opacity: 1;
            visibility: visible;
        }

        /* Float Button */
        .float-btn {
            position: fixed;
            bottom: 30px;
            right: 30px;
            z-index: 999;
            display: flex;
            flex-direction: column;
            align-items: flex-end;
        }

        .whatsapp-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            width: 60px;
            height: 60px;
            background-color: #25D366;
            color: white;
            border-radius: 50%;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
            margin-bottom: 15px;
            font-size: 28px;
            text-decoration: none;
        }

        .whatsapp-btn:hover {
            transform: scale(1.1);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
        }

        .budget-btn {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 15px 25px;
            background-color: var(--secondary);
            color: var(--dark);
            border-radius: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.15);
            transition: all 0.3s ease;
            font-weight: 600;
            text-transform: uppercase;
            font-size: 14px;
            letter-spacing: 1px;
            text-decoration: none;
        }

        .budget-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 16px rgba(0,0,0,0.2);
            background-color: #b5956e;
        }

        .budget-btn i {
            margin-right: 8px;
            font-size: 16px;
        }

        @media (max-width: 768px) {
            .budget-btn {
                padding: 12px 20px;
                font-size: 12px;
            }
            
            .whatsapp-btn {
                width: 50px;
                height: 50px;
                font-size: 24px;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes slideDown {
            from {
                opacity: 0;
                transform: scaleY(0.8);
            }
            to {
                opacity: 1;
                transform: scaleY(1);
            }
        }

        /* Responsive Styles */
        @media (max-width: 992px) {
            .contact-container {
                grid-template-columns: 1fr;
            }
            
            .section {
                padding: 60px 0;
            }
        }

        @media (max-width: 768px) {
            .mobile-menu-btn {
                display: block;
            }
            
            .nav {
                position: fixed;
                top: 90px;
                left: -100%;
                width: 100%;
                background-color: var(--light);
                box-shadow: var(--shadow);
                transition: var(--transition);
                z-index: 999;
            }
            
            .nav.active {
                left: 0;
            }
            
            .nav-list {
                flex-direction: column;
                padding: 20px;
            }
            
            .nav-item {
                margin: 15px 0;
                margin-left: 0;
            }
            
            .login-form {
                flex-direction: column;
                align-items: flex-start;
            }
            
            .login-form .form-control {
                width: 100%;
            }
            
            .login-form .btn-primary {
                width: 100%;
            }
            
            .client-area {
                min-width: 100%;
                max-width: 100%;
                right: 0;
                left: 0;
                margin: 0 auto;
            }
            
            .hero-title {
                font-size: 2.5rem;
            }
            
            .hero-subtitle {
                font-size: 1.1rem;
            }
            
            .process-timeline {
                padding-left: 30px;
            }
            
            .process-timeline::before {
                left: 19px;
            }
            
            .process-icon {
                font-size: 2rem;
            }
            
            .process-content {
                padding: 15px;
            }
            
            .process-content::before {
                left: -10px;
                top: 15px;
                border-top: 10px solid transparent;
                border-bottom: 10px solid transparent;
                border-right: 10px solid var(--accent);
            }
        }

        @media (max-width: 576px) {
            .hero-title {
                font-size: 1.8rem;
            }
            
            .logo-text h1 {
                font-size: 1rem;
            }
            
            .btn {
                padding: 10px 20px;
                font-size: 0.9rem;
            }
        }

        /* Error/Success Messages */
        .error-message, .success-message {
            padding: 10px;
            margin: 10px 0;
            border-radius: var(--border-radius);
            text-align: center;
        }

        .error-message {
            background-color: #ffe6e6;
            color: #cc0000;
        }

        .success-message {
            background-color: #e6ffe6;
            color: #006600;
            transition: opacity 0.5s ease; /* Animação suave de desaparecimento */
        }
    </style>
</head>
<body>
    <!-- Header -->
    <header class="header">
        <div class="container header-container">
            <a href="#" class="logo">
                <div class="logo-wrapper" style="display: flex; align-items: center; gap: 15px;">
                    <img src="https://i.postimg.cc/7Jr5McP7/Imagem.png" 
                         alt="Logotipo Stéfani Uchôa - Arquitetura e Construção" 
                         style="max-width: 50px; height: auto;">
                    <div class="logo-text" style="display: flex; flex-direction: column; line-height: 1.2;">
                        <p style="margin: 0; font-weight: 500; font-size: 1.1rem;">STÉFANI UCHÔA</p>
                        <p style="margin: 0; font-size: 0.7rem; color: var(--secondary);">Arquitetura e Construção</p>
                    </div>
                </div>
            </a>
            
            <nav class="nav">
                <ul class="nav-list">
                    <li class="nav-item"><a href="#home" class="nav-link">Início</a></li>
                    <li class="nav-item"><a href="#servicos" class="nav-link">Serviços</a></li>
                    <li class="nav-item"><a href="#projetos" class="nav-link">Projetos</a></li>
                    <li class="nav-item"><a href="#processo" class="nav-link">Processo</a></li>
                    <li class="nav-item"><a href="#contato" class="nav-link">Contato</a></li>
                    <li class="nav-item"><a href="criar_conta.php" class="nav-link">Criar Conta</a></li>
                    <?php if (isset($_SESSION['logado']) && $_SESSION['logado'] && !$_SESSION['is_admin']): ?>
                        <li class="nav-item">
                            <button class="menu-toggle" aria-label="Área do Cliente" aria-expanded="false">
                                <i class="fas fa-bars"></i>
                            </button>
                            <div class="client-area">
                                <h3>Bem-vindo, <?php echo htmlspecialchars($_SESSION['nome']); ?></h3>
                                <div class="client-table-container">
                                    <table class="client-table">
                                        <thead>
                                            <tr>
                                                <th>Projeto</th>
                                                <th>Status</th>
                                                <th>Última Atualização</th>
                                                <th>Arquiteto Responsável</th>
                                                <th>Previsão de Conclusão</th>
                                                <th>Ações</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Projeto Residencial</td>
                                                <td>Em Andamento</td>
                                                <td>2025-06-15</td>
                                                <td>Stéfani Uchôa</td>
                                                <td>2025-07-01</td>
                                                <td>Indisponível</td>
                                            </tr>
                                            <tr>
                                                <td>Design de Interiores</td>
                                                <td>Concluído</td>
                                                <td>2025-05-30</td>
                                                <td>Ana Silva</td>
                                                <td>2025-05-30</td>
                                                <td>
                                                    <a href="#" class="action-link">Download</a> | 
                                                    <a href="#" class="action-link">Visualizar</a>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>Regularização de Imóvel</td>
                                                <td>Em Andamento</td>
                                                <td>2025-06-10</td>
                                                <td>Carlos Lima</td>
                                                <td>2025-06-25</td>
                                                <td>Indisponível</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <form action="index.php" method="post">
                                    <button type="submit" class="btn-logout" name="logout">Sair</button>
                                </form>
                            </div>
                        </li>
                    <?php elseif (!isset($_SESSION['logado']) || !$_SESSION['logado']): ?>
                        <li class="nav-item login-form">
                            <form action="index.php" method="post">
                                <input type="email" class="form-control" placeholder="Email" name="email" required>
                                <input type="password" class="form-control" placeholder="Senha" name="senha" required>
                                <button type="submit" class="btn-primary" name="login">Entrar</button>
                            </form>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <button class="mobile-menu-btn" aria-label="Menu" aria-expanded="false">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>

    <!-- Hero Section -->
    <section class="hero" id="home">
        <div class="container">
            <div class="hero-content">
                <?php if ($error): ?>
                    <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
                <?php endif; ?>
                <?php if ($success): ?>
                    <div class="success-message" id="success-message"><?php echo htmlspecialchars($success); ?></div>
                <?php endif; ?>
                <h5 class="hero-title">A 10 anos transformando espaços, criando experiências</h5>
                <p class="hero-subtitle">Arquitetura residencial e projetos personalizados para todo o Brasil</p>
                <div class="cau-badge">CAU A140246-3</div>
            </div>
        </div>
    </section>

    <!-- Services Section -->
    <section class="section" id="servicos">
        <div class="container">
            <h2 class="section-title">Serviços Profissionais</h2>
            
            <div class="services-container">
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-home"></i>
                    </div>
                    <h3 class="service-title">Projetos Residenciais</h3>
                    <p class="service-text">Desenvolvimento completo de projetos arquitetônicos residenciais, desde o estudo preliminar até o projeto executivo.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-couch"></i>
                    </div>
                    <h3 class="service-title">Design de Interiores</h3>
                    <p class="service-text">Criação de móveis planejados e soluções espaciais inteligentes que combinam funcionalidade e estética.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-file-signature"></i>
                    </div>
                    <h3 class="service-title">Regularização de Imóveis</h3>
                    <p class="service-text">Assessoria completa para regularização de obras e propriedades, garantindo conformidade com as normas.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-chess-board"></i>
                    </div>
                    <h3 class="service-title">Projeto de Móveis</h3>
                    <p class="service-text">Design exclusivo de móveis planejados que se integram perfeitamente ao seu espaço e estilo de vida.</p>
                </div>
                
                <div class="service-card">
                    <div class="service-icon">
                        <i class="fas fa-search-dollar"></i>
                    </div>
                    <h3 class="service-title">Avaliação de Imóveis</h3>
                    <p class="service-text">Perícias e avaliações técnicas para compra, venda ou fins jurídicos, com laudo técnico detalhado.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- Projects Section -->
    <section class="section projects" id="projetos">
        <div class="container">
            <h2 class="section-title">Portfólio</h2>
            
            <div class="swiper-container">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/bgJxDGKb/Captura-de-Tela-2025-06-18-a-s-21-57-28.png" 
                             alt="Projeto residencial moderno em Macapá">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/XZR6CsNB/Captura-de-Tela-2025-06-18-a-s-21-57-55.png"
                             alt="Detalhe de design de interiores">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/hFJx9LXz/Captura-de-Tela-2025-06-18-a-s-21-58-34.png"
                             alt="Projeto arquitetônico completo">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/nMwk5RSt/Captura-de-Tela-2025-06-18-a-s-22-22-53.png" 
                             alt="Outro ângulo do projeto residencial">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/bRM73SNz/4.webp" 
                             alt="Detalhe de móveis planejados">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://i.ibb.co/Ps3R7mVy/Captura-de-Tela-2025-06-18-a-s-22-26-59.png">
                    </div>
                    <div class="swiper-slide">
                        <img src="https://images.adsttc.com/media/images/6516/0037/1748/5301/7c3c/67cc/large_jpg/casa-patio-caio-persighini-arquitetura_21.jpg?1695940677" 
                             alt="Projeto completo em 3D">
                    </div>
                </div>
                <div class="swiper-button-next"></div>
                <div class="swiper-button-prev"></div>
            </div>
        </div>
    </section>

    <!-- Process Section -->
    <section class="section process-section" id="processo">
        <div class="container">
            <h2 class="section-title">Nosso Processo de Trabalho</h2>
            
            <div class="process-timeline">
                <div class="process-item">
                    <div class="process-icon">
                        <i class="fas fa-comments"></i>
                    </div>
                    <div class="process-content">
                        <h3>Reunião de Coleta de Dados</h3>
                        <p>É nesse momento que a gente se conhece melhor, e você me conta tudo o que gostaria de ter, ser e fazer na sua casa nova!</p>
                    </div>
                </div>
                
                <div class="process-item">
                    <div class="process-icon">
                        <i class="fas fa-drafting-compass"></i>
                    </div>
                    <div class="process-content">
                        <h3>Apresentação do Projeto</h3>
                        <p>Seu projeto ganhará forma e você verá imagens 3D de fácil compreensão.</p>
                    </div>
                </div>
                
                <div class="process-item">
                    <div class="process-icon">
                        <i class="fas fa-edit"></i>
                    </div>
                    <div class="process-content">
                        <h3>Alterações Necessárias</h3>
                        <p>Poderemos fazer alterações e correções no projeto.</p>
                    </div>
                </div>
                
                <div class="process-item">
                    <div class="process-icon">
                        <i class="fas fa-tools"></i>
                    </div>
                    <div class="process-content">
                        <h3>Projeto Detalhado</h3>
                        <p>Faremos detalhamentos do projeto para que os profissionais da obra saibam exatamente o que fazer e como fazer.</p>
                    </div>
                </div>
                
                <div class="process-item">
                    <div class="process-icon">
                        <i class="fas fa-hard-hat"></i>
                    </div>
                    <div class="process-content">
                        <h3>Assistência à Obra</h3>
                        <p>Se você quiser, também poderemos oferecer assistência à sua obra e aos serviços executados.</p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Contact Section -->
    <section class="section" id="contato">
        <div class="container">
            <h2 class="section-title">Entre em Contato</h2>
            <?php if ($error): ?>
                <div class="error-message"><?php echo htmlspecialchars($error); ?></div>
            <?php endif; ?>
           <div class="contact-container">
                <div class="contact-info">
                    <h3>Informações</h3>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fab fa-whatsapp"></i>
                        </div>
                        <div class="contact-text">
                            <h4>WhatsApp</h4>
                            <p><a href="https://wa.me/5596981419268">(96) 98141-9268</a></p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-envelope"></i>
                        </div>
                        <div class="contact-text">
                            <h4>Email</h4>
                            <p><a href="mailto:arq.stefaniuchoa@gmail.com">arq.stefaniuchoa@gmail.com</a></p>
                        </div>
                    </div>
                    
                    <div class="contact-item">
                        <div class="contact-icon">
                            <i class="fas fa-map-marker-alt"></i>
                        </div>
                        <div class="contact-text">
                            <h4>Localização</h4>
                            <p>Macapá - Amapá</p>
                        </div>
                    </div>
                    
                    <div class="social-links">
                        <a href="https://www.instagram.com/stefani_uchoa_arquitetura/" class="social-link" target="_blank" aria-label="Instagram">
                            <i class="fab fa-instagram"></i>
                        </a>
                        <a href="https://facebook.com/arq.stefaniuchoa" class="social-link" target="_blank" aria-label="Facebook">
                            <i class="fab fa-facebook-f"></i>
                        </a>
                        <a href="https://linkedin.com/in/stefaniuchoa" class="social-link" target="_blank" aria-label="LinkedIn">
                            <i class="fab fa-linkedin-in"></i>
                        </a>
                    </div>
                </div>
                
                <div class="contact-form">
                    <form action="enviar_contato.php" method="post" id="contactForm">
                        <div class="form-group">
                            <input type="text" class="form-control" placeholder="Seu nome" name="nome" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="email" class="form-control" placeholder="Seu email" name="email" required>
                        </div>
                        
                        <div class="form-group">
                            <input type="tel" class="form-control" placeholder="Seu telefone" name="telefone">
                        </div>
                        
                        <div class="form-group">
                            <select class="form-control" name="assunto" required>
                                <option value="" disabled selected>Assunto</option>
                                <option value="projeto">Orçamento para Projeto</option>
                                <option value="regularizacao">Regularização de Imóvel</option>
                                <option value="duvidas">Dúvidas</option>
                                <option value="outros">Outros</option>
                            </select>
                        </div>
                        
                        <div class="form-group">
                            <textarea class="form-control" placeholder="Sua mensagem" name="mensagem" required></textarea>
                        </div>
                        
                        <button type="submit" class="btn">Enviar Mensagem</button>
                    </form>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        <div class="container">
            <div class="footer-container">
                <div class="footer-col footer-about">
                    <h3>Stéfani Uchôa</h3>
                    <p>Arquiteta e Urbanista registrada no CAU sob o número A140246-3, atuando em todo o Brasil com excelência em projetos residenciais e Construções.</p>
                </div>
                
                <div class="footer-col">
                    <h3>Links Rápidos</h3>
                    <ul class="footer-links">
                        <li><a href="#home">Início</a></li>
                        <li><a href="#servicos">Serviços</a></li>
                        <li><a href="#projetos">Projetos</a></li>
                        <li><a href="#processo">Processo</a></li>
                        <li><a href="#contato">Contato</a></li>
                    </ul>
                </div>
                
                <div class="footer-col">
                    <h3>Serviços</h3>
                    <ul class="footer-links">
                        <li><a href="#servicos">Projetos Residenciais</a></li>
                        <li><a href="#servicos">Design de Interiores</a></li>
                        <li><a href="#servicos">Regularização de Imóveis</a></li>
                        <li><a href="#servicos">Avaliações e Perícias</a></li>
                    </ul>
                </div>
                
                <div class="footer-col footer-contact">
                    <h3>Contato</h3>
                    <p><i class="fab fa-whatsapp"></i> (96) 98141-9268</p>
                    <p><i class="fas fa-envelope"></i> contato@stefaniuchoa.arq.br</p>
                    <p><i class="fas fa-map-marker-alt"></i> Macapá - Amapá</p>
                </div>
            </div>
        </div>
        
        <div class="footer-bottom">
            <div class="container">
                <p>© 2025 Stéfani Uchôa Arquitetura. Todos os direitos reservados.</p>
            </div>
        </div>
    </footer>

    <!-- Back to Top Button -->
    <button class="back-to-top" aria-label="Voltar ao topo">
        <i class="fas fa-arrow-up"></i>
    </button>

    <!-- Float Button -->
    <div class="float-btn">
        <a href="https://wa.me/5596981419268" class="whatsapp-btn" target="_blank" aria-label="WhatsApp">
            <i class="fab fa-whatsapp"></i>
        </a>
        <a href="#contato" class="budget-btn">
            <i class="fas fa-file-invoice-dollar"></i> Orçamento
        </a>
    </div>

    <!-- LightGallery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/js/lightgallery.min.js"></script>
    
    <!-- Swiper JS -->
    <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
    
    <!-- Main JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Mobile Menu Toggle
            const mobileMenuBtn = document.querySelector('.mobile-menu-btn');
            const nav = document.querySelector('.nav');
            
            mobileMenuBtn.addEventListener('click', function() {
                const expanded = this.getAttribute('aria-expanded') === 'true';
                this.setAttribute('aria-expanded', !expanded);
                nav.classList.toggle('active');
                
                const icon = this.querySelector('i');
                icon.classList.toggle('fa-bars');
                icon.classList.toggle('fa-times');
            });
            
            // Client Area Toggle
            const menuToggle = document.querySelector('.menu-toggle');
            const clientArea = document.querySelector('.client-area');
            
            if (menuToggle && clientArea) {
                menuToggle.addEventListener('click', function() {
                    const expanded = this.getAttribute('aria-expanded') === 'true';
                    this.setAttribute('aria-expanded', !expanded);
                    clientArea.classList.toggle('active');
                    
                    const icon = this.querySelector('i');
                    icon.classList.toggle('fa-bars');
                    icon.classList.toggle('fa-times');
                });
            }
            
            // Smooth Scrolling for Navigation Links
            document.querySelectorAll('.nav-link').forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const href = this.getAttribute('href');
                    
                    if (href.startsWith('#')) {
                        const sectionId = href.substring(1);
                        try {
                            const section = document.getElementById(sectionId);
                            if (section) {
                                window.scrollTo({
                                    top: section.offsetTop - 80,
                                    behavior: 'smooth'
                                });
                                history.pushState(null, null, `#${sectionId}`);
                            }
                        } catch (error) {
                            console.error('Erro ao rolar:', error);
                        }
                    } else {
                        window.location.href = href;
                    }
                    
                    if (nav.classList.contains('active')) {
                        nav.classList.remove('active');
                        mobileMenuBtn.setAttribute('aria-expanded', 'false');
                        mobileMenuBtn.querySelector('i').classList.remove('fa-times');
                        mobileMenuBtn.querySelector('i').classList.add('fa-bars');
                    }
                });
            });
            
            // Header Scroll Effect
            window.addEventListener('scroll', function() {
                const header = document.querySelector('.header');
                const backToTop = document.querySelector('.back-to-top');
                
                if (window.scrollY > 100) {
                    header.classList.add('scrolled');
                    backToTop.classList.add('active');
                } else {
                    header.classList.remove('scrolled');
                    backToTop.classList.remove('active');
                }
            });
            
            // Back to Top Button
            document.querySelector('.back-to-top').addEventListener('click', function() {
                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            });
            
            // Initialize Swiper
            const swiper = new Swiper('.swiper-container', {
                loop: true,
                slidesPerView: 3,
                spaceBetween: 20,
                centeredSlides: true,
                autoplay: {
                    delay: 0,
                    disableOnInteraction: false
                },
                speed: 5000,
                freeMode: {
                    enabled: true,
                    momentum: false
                },
                grabCursor: true,
                navigation: {
                    nextEl: '.swiper-button-next',
                    prevEl: '.swiper-button-prev'
                },
                breakpoints: {
                    768: {
                        slidesPerView: 2,
                        spaceBetween: 15
                    },
                    480: {
                        slidesPerView: 1,
                        spaceBetween: 10
                    }
                }
            });

            swiper.el.addEventListener('mouseenter', () => {
                swiper.autoplay.stop();
            });

            swiper.el.addEventListener('mouseleave', () => {
                swiper.autoplay.start();
            });
            
            // Contact Form Submission
            const contactForm = document.getElementById('contactForm');
            if (contactForm) {
                contactForm.addEventListener('submit', function(e) {
                    const submitBtn = this.querySelector('button[type="submit"]');
                    const originalText = submitBtn.textContent;
                    
                    submitBtn.disabled = true;
                    submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Enviando...';
                });
            }
            
            // Check URL hash on load
            if (window.location.hash) {
                const sectionId = window.location.hash.substring(1);
                const section = document.getElementById(sectionId);
                
                if (section) {
                    setTimeout(() => {
                        window.scrollTo({
                            top: section.offsetTop - 80,
                            behavior: 'smooth'
                        });
                    }, 100);
                }
            }
        });
    </script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const successMessage = document.getElementById('success-message');
        if (successMessage) {
            setTimeout(() => {
                successMessage.style.transition = 'opacity 0.5s';
                successMessage.style.opacity = '0'; // Inicia o fade-out
                setTimeout(() => {
                    successMessage.remove(); // Remove completamente do DOM
                }, 500); // Tempo da animação de fade-out (0.5s)
            }, 2000); // Tempo que a mensagem fica visível (2s)
        }
    });
</script>

<?php if (isset($_SESSION['is_smayk']) && $_SESSION['is_smayk']): ?>
    <form method="POST" enctype="multipart/form-data">
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Status</th>
                    <th>Previsão</th>
                    <th>Arquiteta Responsável</th>
                    <th>Arquivo</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($projeto = $projetos->fetch_assoc()): ?>
                <tr>
                    <td><input type="text" name="nome_<?= $projeto['id'] ?>" value="<?= htmlspecialchars($projeto['nome']) ?>"></td>
                    <td>
                        <select name="status_<?= $projeto['id'] ?>">
                            <option value="Em Andamento" <?= $projeto['status'] == 'Em Andamento' ? 'selected' : '' ?>>Em Andamento</option>
                            <option value="Concluído" <?= $projeto['status'] == 'Concluído' ? 'selected' : '' ?>>Concluído</option>
                        </select>
                    </td>
                    <td><input type="date" name="previsao_<?= $projeto['id'] ?>" value="<?= $projeto['previsao'] ?>"></td>
                    <td><input type="text" name="arquiteta_<?= $projeto['id'] ?>" value="<?= htmlspecialchars($projeto['arquiteta']) ?>"></td>
                    <td>
                        <input type="file" name="arquivo_<?= $projeto['id'] ?>">
                        <a href="uploads/projetos/<?= $projeto['arquivo'] ?>" target="_blank">Ver Atual</a>
                    </td>
                    <td>
                        <button type="submit" name="salvar_<?= $projeto['id'] ?>">Salvar</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </form>
<?php endif; ?>
<?php
session_start();
if (!isset($_SESSION['logado'])) {
    header('Location: index.php');
    exit;
}

require_once 'db_connect.php';
$projetos = $conn->query("SELECT * FROM projetos");
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Administração de Projetos | Stéfani Uchôa Arquitetura</title>
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        :root {
            --primary: #2A5C7D;
            --secondary: #C5A47E;
            --accent: #F8F9FA;
            --dark: #1A1A1A;
            --light: #FFFFFF;
            --text: #333333;
            --text-light: #777777;
            --shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            --transition: all 0.3s ease;
            --border-radius: 8px;
            --max-width: 1200px;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            background-color: var(--accent);
            color: var(--text);
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: var(--max-width);
            margin: 80px auto 40px;
            padding: 20px;
            background-color: var(--light);
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
        }

        h1 {
            color: var(--primary);
            text-align: center;
            margin-bottom: 30px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--secondary);
        }

        .upload-section {
            background-color: var(--light);
            padding: 25px;
            border-radius: var(--border-radius);
            margin-bottom: 30px;
            box-shadow: var(--shadow);
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: var(--primary);
        }

        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            font-size: 1rem;
            transition: var(--transition);
        }

        .form-control:focus {
            border-color: var(--secondary);
            outline: none;
            box-shadow: 0 0 0 3px rgba(197, 164, 126, 0.2);
        }

        .btn {
            display: inline-block;
            padding: 12px 25px;
            background-color: var(--secondary);
            color: var(--dark);
            border: none;
            border-radius: var(--border-radius);
            font-weight: 600;
            cursor: pointer;
            transition: var(--transition);
            text-align: center;
        }

        .btn:hover {
            background-color: #b5956e;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        .btn-primary {
            background-color: var(--primary);
            color: var(--light);
        }

        .btn-primary:hover {
            background-color: #1e4560;
        }

        .projects-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            box-shadow: var(--shadow);
        }

        .projects-table th {
            background-color: var(--primary);
            color: var(--light);
            padding: 15px;
            text-align: left;
        }

        .projects-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #eee;
        }

        .projects-table tr:nth-child(even) {
            background-color: rgba(197, 164, 126, 0.05);
        }

        .projects-table tr:hover {
            background-color: rgba(197, 164, 126, 0.1);
        }

        .action-btn {
            padding: 6px 12px;
            margin-right: 5px;
            border-radius: 4px;
            font-size: 0.9rem;
            transition: var(--transition);
        }

        .download-btn {
            background-color: var(--primary);
            color: white;
            text-decoration: none;
        }

        .download-btn:hover {
            background-color: #1e4560;
        }

        .edit-btn {
            background-color: var(--secondary);
            color: var(--dark);
            text-decoration: none;
        }

        .edit-btn:hover {
            background-color: #b5956e;
        }

        .delete-btn {
            background-color: #dc3545;
            color: white;
            text-decoration: none;
        }

        .delete-btn:hover {
            background-color: #bb2d3b;
        }

        .file-upload {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .file-upload-label {
            padding: 8px 15px;
            background-color: var(--primary);
            color: white;
            border-radius: var(--border-radius);
            cursor: pointer;
            transition: var(--transition);
        }

        .file-upload-label:hover {
            background-color: #1e4560;
        }

        .file-input {
            display: none;
        }

        @media (max-width: 768px) {
            .admin-container {
                margin: 60px 15px;
                padding: 15px;
            }
            
            .projects-table {
                display: block;
                overflow-x: auto;
            }
        }
    </style>
</head>
<body>
    <div class="admin-container">
        <h1><i class="fas fa-folder-open"></i> Administração de Projetos</h1>
        
        <?php if (isset($_SESSION['is_smayk']) || isset($_SESSION['is_admin'])): ?>
        <div class="upload-section">
            <h2><i class="fas fa-cloud-upload-alt"></i> Adicionar Novo Projeto</h2>
            <form method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="nome">Nome do Projeto</label>
                    <input type="text" id="nome" name="nome" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="arquiteto">Arquiteto Responsável</label>
                    <input type="text" id="arquiteto" name="arquiteto" class="form-control" required>
                </div>
                
                <div class="form-group">
                    <label for="status">Status</label>
                    <select id="status" name="status" class="form-control" required>
                        <option value="Em Andamento">Em Andamento</option>
                        <option value="Concluído">Concluído</option>
                        <option value="Pendente">Pendente</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label class="file-upload-label" for="arquivo">
                        <i class="fas fa-file-upload"></i> Selecionar Arquivo
                    </label>
                    <input type="file" id="arquivo" name="arquivo" class="file-input" accept=".pdf,.jpg,.png,.zip,.doc,.docx" required>
                    <span id="file-name">Nenhum arquivo selecionado</span>
                </div>
                
                <button type="submit" class="btn btn-primary">
                    <i class="fas fa-save"></i> Salvar Projeto
                </button>
            </form>
        </div>
        <?php endif; ?>
        
        <h2><i class="fas fa-list"></i> Projetos Cadastrados</h2>
        <table class="projects-table">
            <thead>
                <tr>
                    <th>Projeto</th>
                    <th>Status</th>
                    <th>Arquiteto</th>
                    <th>Data</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($projeto = $projetos->fetch_assoc()): ?>
                <?php
                $arquivoPath = "uploads/projetos/" . $projeto['arquivo'];
                $arquivoDisponivel = file_exists($arquivoPath) && !empty($projeto['arquivo']);
                ?>
                <tr>
                    <td><?= htmlspecialchars($projeto['nome']) ?></td>
                    <td><?= htmlspecialchars($projeto['status']) ?></td>
                    <td><?= htmlspecialchars($projeto['arquiteto']) ?></td>
                    <td><?= date('d/m/Y', strtotime($projeto['data_upload'])) ?></td>
                    <td>
                        <?php if ($arquivoDisponivel): ?>
                            <a href="<?= $arquivoPath ?>" download class="action-btn download-btn">
                                <i class="fas fa-download"></i> Baixar
                            </a>
                        <?php else: ?>
                            <span class="action-btn" style="background-color: #6c757d; color: white;">
                                <i class="fas fa-times-circle"></i> Indisponível
                            </span>
                        <?php endif; ?>
                        
                        <?php if (isset($_SESSION['is_smayk']) || isset($_SESSION['is_admin'])): ?>
                            <a href="editar_projeto.php?id=<?= $projeto['id'] ?>" class="action-btn edit-btn">
                                <i class="fas fa-edit"></i> Editar
                            </a>
                            <a href="excluir_projeto.php?id=<?= $projeto['id'] ?>" class="action-btn delete-btn" onclick="return confirm('Tem certeza que deseja excluir este projeto?')">
                                <i class="fas fa-trash-alt"></i> Excluir
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        // Mostrar nome do arquivo selecionado
        document.getElementById('arquivo').addEventListener('change', function(e) {
            const fileName = e.target.files[0] ? e.target.files[0].name : 'Nenhum arquivo selecionado';
            document.getElementById('file-name').textContent = fileName;
        });

        // Confirmação antes de excluir
        document.querySelectorAll('.delete-btn').forEach(btn => {
            btn.addEventListener('click', function(e) {
                if (!confirm('Tem certeza que deseja excluir este projeto?')) {
                    e.preventDefault();
                }
            });
        });
    </script>
</body>
</html>
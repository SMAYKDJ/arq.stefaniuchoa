<?php
session_start();
if (!isset($_SESSION['logado']) || !isset($_SESSION['is_admin']) || !$_SESSION['is_admin']) {
    header('Location: index.php');
    exit;
}

require_once 'db_connect.php';

// Processar upload de projetos
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['upload_projeto'])) {
    $nome_projeto = $_POST['nome_projeto'];
    $arquiteto = $_POST['arquiteto'];
    $status = $_POST['status'];
    $previsao = $_POST['previsao'];
    $arquivo = $_FILES['arquivo'];

    $extensoesPermitidas = ['pdf', 'jpg', 'png', 'zip'];
    $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));

    if (!in_array($extensao, $extensoesPermitidas)) {
        echo "<script>alert('Tipo de arquivo não permitido!');</script>";
    } else {
        // Garante que a pasta existe
        $pasta_upload = "uploads/projetos/";
        if (!is_dir($pasta_upload)) {
            mkdir($pasta_upload, 0777, true);
        }
        $nome_arquivo = uniqid() . '_' . basename($arquivo['name']);
        $caminho_completo = $pasta_upload . $nome_arquivo;

        if ($arquivo['error'] === UPLOAD_ERR_OK && move_uploaded_file($arquivo['tmp_name'], $caminho_completo)) {
            // Salvar no banco de dados
            $stmt = $conn->prepare("INSERT INTO projetos (nome, arquivo, status, arquiteto) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $nome_projeto, $nome_arquivo, $status, $arquiteto);
            if ($stmt->execute()) {
                echo "<script>alert('Arquivo enviado e projeto cadastrado com sucesso!');</script>";
            } else {
                echo "<script>alert('Erro ao salvar no banco de dados.');</script>";
            }
            $stmt->close();
        } else {
            echo "<script>alert('Erro ao fazer upload do arquivo.');</script>";
        }
    }
}

// Buscar projetos existentes
$projetos = [];
$stmt = $conn->prepare("SELECT * FROM projetos ORDER BY id DESC");
$stmt->execute();
$result = $stmt->get_result();
while ($row = $result->fetch_assoc()) {
    $projetos[] = $row;
}
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Admin - Stéfani Uchôa</title>
    <meta name="description" content="Painel de administração - Stéfani Uchôa Arquitetura e Urbanismo">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    
    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">
    
    <style>
        /* Variáveis CSS */
        :root {
            --primary: #2A5C7D;
            --secondary: #C5A47E;
            --accent: #F8F9FA;
            --dark: #1A1A1A;
            --light: #FFFFFF;
            --text: #333333;
            --text-light: #777777;
            --shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            --transition: all 0.3s ease;
            --border-radius: 8px;
            --max-width: 1200px;
        }

        /* Reset e Base */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Montserrat', sans-serif;
            font-weight: 700;
            line-height: 1.6;
            color: #2A5C7D;
            background-color: var(--light);
            overflow-x: hidden;
        }

        .container {
            width: 90%;
            max-width: var(--max-width);
            margin: 0 auto;
            padding: 0 15px;
        }

        /* Admin Section */
        .admin-section {
            padding: 100px 0;
            min-height: 100vh;
        }

        .admin-container {
            background-color: var(--light);
            padding: 40px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            text-align: center;
        }

        .admin-container h2 {
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 20px;
        }

        .admin-container h3 {
            color: var(--primary);
            margin: 30px 0 15px;
        }

        .admin-container p {
            color: var(--text-light);
            margin-bottom: 30px;
        }

        .btn-primary {
            display: inline-block;
            padding: 12px 30px;
            background-color: var(--primary);
            color: var(--light);
            border-radius: var(--border-radius);
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 1px;
            transition: var(--transition);
            border: none;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #1e4560;
            transform: translateY(-3px);
            box-shadow: var(--shadow);
        }

        /* Tabela de Projetos */
        .projetos-table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        .projetos-table th, .projetos-table td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        .projetos-table th {
            background-color: var(--secondary);
            color: var(--light);
            font-weight: 600;
        }

        .projetos-table tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        .projetos-table tr:hover {
            background-color: #f1f1f1;
        }

        /* Formulário de Upload */
        .upload-form {
            background-color: var(--light);
            padding: 30px;
            border-radius: var(--border-radius);
            box-shadow: var(--shadow);
            margin-bottom: 40px;
        }

        .upload-form h3 {
            margin-bottom: 20px;
        }

        .upload-form label {
            display: block;
            margin-bottom: 8px;
            text-align: left;
        }

        .upload-form input[type="text"],
        .upload-form input[type="file"],
        .upload-form select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: var(--border-radius);
            margin-bottom: 15px;
        }

        .upload-form input[type="submit"] {
            background-color: var(--primary);
            color: var(--light);
            border: none;
            border-radius: var(--border-radius);
            padding: 12px 20px;
            cursor: pointer;
            font-weight: 600;
            transition: var(--transition);
        }

        .upload-form input[type="submit"]:hover {
            background-color: #1e4560;
            transform: translateY(-2px);
            box-shadow: var(--shadow);
        }

        /* Responsividade */
        @media (max-width: 768px) {
            .admin-container {
                padding: 20px;
            }

            .btn-primary {
                padding: 10px 20px;
                font-size: 14px;
            }

            .upload-form input[type="text"],
            .upload-form input[type="file"],
            .upload-form select {
                padding: 8px;
            }

            .upload-form input[type="submit"] {
                padding: 10px 15px;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="admin-section">
            <div class="admin-container">
                <h2>Painel Administrativo</h2>
                <p>Bem-vindo, <?php echo $_SESSION['nome']; ?>!</p>

                <!-- Botão de Logout -->
                <form method="POST" style="display: inline;">
                    <input type="submit" name="logout" value="Logout" class="btn-primary">
                </form>

                <!-- Seção de Upload de Projetos -->
                <div class="upload-form">
                    <h3>Upload de Novo Projeto</h3>
                    <form method="POST" enctype="multipart/form-data">
                        <label for="nome_projeto">Nome do Projeto:</label>
                        <input type="text" id="nome_projeto" name="nome_projeto" required>

                        <label for="arquiteto">Arquiteto Responsável:</label>
                        <input type="text" id="arquiteto" name="arquiteto" required>

                        <label for="status">Status:</label>
                        <select id="status" name="status" required>
                            <option value="em_andamento">Em Andamento</option>
                            <option value="concluido">Concluído</option>
                            <option value="suspendido">Suspenso</option>
                        </select>

                        <label for="previsao">Previsão de Entrega:</label>
                        <input type="text" id="previsao" name="previsao" placeholder="DD/MM/AAAA" required>

                        <label for="arquivo">Arquivo do Projeto:</label>
                        <input type="file" id="arquivo" name="arquivo" accept=".pdf, .jpg, .jpeg, .png, .gif" required>

                        <input type="submit" name="upload_projeto" value="Upload Projeto">
                    </form>
                </div>

                <!-- Tabela de Projetos -->
                <h3>Projetos Cadastrados</h3>
                <table class="projetos-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Arquiteto</th>
                            <th>Status</th>
                            <th>Previsão de Entrega</th>
                            <th>Arquivo</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($projetos)): ?>
                            <tr>
                                <td colspan="7">Nenhum projeto cadastrado.</td>
                            </tr>
                        <?php else: ?>
                            <?php foreach ($projetos as $projeto): ?>
                                <tr>
                                    <td><?php echo $projeto['id']; ?></td>
                                    <td><?php echo $projeto['nome']; ?></td>
                                    <td><?php echo $projeto['arquiteto']; ?></td>
                                    <td><?php echo ucfirst($projeto['status']); ?></td>
                                    <td><?php echo date('d/m/Y', strtotime($projeto['previsao'])); ?></td>
                                    <td>
                                        <a href="uploads/projetos/<?php echo $projeto['arquivo']; ?>" target="_blank" class="btn-primary">
                                            <i class="fas fa-file-download"></i> Baixar
                                        </a>
                                    </td>
                                    <td>
                                        <!-- Ações: Editar e Excluir -->
                                        <a href="editar_projeto.php?id=<?php echo $projeto['id']; ?>" class="btn-primary">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <a href="excluir_projeto.php?id=<?php echo $projeto['id']; ?>" class="btn-primary" onclick="return confirm('Tem certeza que deseja excluir este projeto?');">
                                            <i class="fas fa-trash"></i> Excluir
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</body>
</html>
<?php
session_start();
if (!isset($_SESSION['logado'])) die("Acesso negado!");

$arquivo = $_GET['arquivo'];
$caminho = 'uploads/projetos/' . basename($arquivo);

if (file_exists($caminho)) {
    header('Content-Type: application/octet-stream');
    header('Content-Disposition: attachment; filename="' . basename($caminho) . '"');
    readfile($caminho);
    exit;
} else {
    die("Arquivo não encontrado!");
}
?>